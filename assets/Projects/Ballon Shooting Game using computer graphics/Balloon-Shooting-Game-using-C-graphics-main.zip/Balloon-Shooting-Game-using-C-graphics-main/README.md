# Balloon-Shooting-Game-using-C-graphics
I have created Balloon Shooting game using C graphics. User can play game in 3 levels. If he/she has cleared first level then only he/she can play next level. The speed of balloons will change with every level. I have used graphics.h header file for drawing the balloons, arrows, etc.,
