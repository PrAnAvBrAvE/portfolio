# Car-Showroom-Management-System-using-C-
I have developed Car Showroom Management System using C++. I have used concept of inheritance and defining methods outside classes. User can see the features of desired car and purchase the car. Receipt will be automatically generated.
